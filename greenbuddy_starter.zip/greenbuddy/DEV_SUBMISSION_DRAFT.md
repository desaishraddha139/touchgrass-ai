---
title: "GreenBuddy: A Local AI Gardening Companion That Gets You Outside"
published: false
tags: devchallenge, hf26challenge, python, ai
---

*This is a submission for the [Hacktoberfest Open-Source AI Challenge Week 1: Touch Grass](https://dev.to/challenges/hacktoberfest-week1-2026-10-05).*

## What I Built

GreenBuddy is a beginner-friendly gardening companion. Users enter their region, growing space, sunlight, and gardening goals. A locally running AI model creates plant ideas, a simple seven-day plan, and a small outdoor task to try today.

The goal is simple: use the screen to make a plan, then go outside and do it.

## Demo

[Add your deployed demo link or a short video link here.]

## Code

[Add your GitHub repository URL here.]

## How I Built It

I built the interface with Python and Streamlit. The app sends the user's gardening preferences to Qwen2.5 1.5B Instruct running locally through Ollama. The model generates the gardening plan on the user's own computer.

[Add a screenshot and describe what you tested on your computer.]

## Why Does Open Innovation Matter?

Using an open-weight model that runs locally gives users more control over where their prompts are processed. After the initial model download, GreenBuddy can generate plans without sending gardening questions to a hosted AI API. The local setup also makes it possible to inspect the code and experiment with different compatible models.

This approach has trade-offs: the model needs disk space and memory, and its advice must be checked against local conditions. I chose local inference because privacy, experimentation, and the ability to run without a live AI API are useful for a small personal gardening tool.

## My Agent Session

[Optional: add a DevRelay session link.]

## Prize Categories

[Add any applicable partner category only if your project meets its requirements; otherwise remove this section.]

---

**Before publishing:** Replace all bracketed placeholders with your real repository, demo, screenshots, and experience. Do not claim features or testing you have not completed.
