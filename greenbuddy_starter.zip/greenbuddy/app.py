import streamlit as st
from ollama import chat

st.set_page_config(page_title="GreenBuddy 🌱", page_icon="🌱", layout="centered")

st.title("🌱 GreenBuddy")
st.subheader("Your local AI gardening companion")
st.write("Make a small plan, step outside, and help something grow.")

with st.sidebar:
    st.header("About this project")
    st.write("GreenBuddy uses a locally running open-weight AI model through Ollama.")
    st.write("After the model is downloaded, your gardening prompts can stay on your computer.")
    st.caption("AI suggestions can be wrong. Check local growing conditions and plant safety.")

with st.form("garden_form"):
    location = st.text_input("Your city or region", placeholder="e.g., Kankavli, Maharashtra")
    season = st.selectbox("Current season", ["Monsoon", "Post-monsoon", "Winter", "Summer", "Not sure"])
    space = st.selectbox("Where will you grow plants?", ["Balcony or pots", "Small garden", "Farm or large garden", "Indoor windowsill"])
    sunlight = st.selectbox("Sunlight available", ["Less than 3 hours", "3–6 hours", "More than 6 hours", "Not sure"])
    experience = st.selectbox("Gardening experience", ["Beginner", "Some experience", "Experienced"])
    interests = st.multiselect(
        "What would you like to grow?",
        ["Leafy greens", "Herbs", "Tomatoes", "Chillies", "Flowers", "Native plants", "Anything easy"]
    )
    goal = st.selectbox("Your goal", ["Start a garden", "Improve plant health", "Grow food", "Support pollinators", "Build a daily outdoor habit"])
    submitted = st.form_submit_button("Create my garden plan 🌿", type="primary")

if submitted:
    if not location.strip():
        st.warning("Please enter your city or region so the plan has some local context.")
    else:
        preferences = ", ".join(interests) if interests else "easy beginner-friendly plants"
        prompt = f"""
You are GreenBuddy, a practical gardening companion whose purpose is to help people spend more time outdoors.
Create a concise, safe, realistic gardening plan for the user below.

Location/region: {location}
Season selected by user: {season}
Growing space: {space}
Sunlight: {sunlight}
Experience: {experience}
Interests: {preferences}
Goal: {goal}

Respond with these headings:
1. Three suitable plant ideas (explain that local conditions should be checked)
2. A simple 7-day plan with one short outdoor task per day
3. Basic watering and care tips
4. One 10-minute task to do today away from the screen
5. One question the user can observe outdoors and write down afterwards

Keep the plan beginner-friendly and practical. Do not invent exact local weather or frost dates.
If a recommendation depends on local climate, soil, or season, say so clearly.
"""
        with st.spinner("GreenBuddy is thinking locally..."):
            try:
                response = chat(
                    model="qwen2.5:1.5b-instruct-q5_0",
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a helpful, cautious gardening assistant. Encourage outdoor activity and give practical, non-alarmist advice."
                        },
                        {"role": "user", "content": prompt},
                    ],
                    options={"temperature": 0.7},
                )
                st.markdown(response.message.content)
                st.success("Your next step: close this tab and try today's 10-minute garden task.")
            except Exception:
                st.error(
                    "I couldn't reach the local AI model. Check that Ollama is installed and running, "
                    "then run this command in a terminal: ollama run qwen2.5:1.5b-instruct-q5_0"
                )
                st.info("The app needs the model downloaded once before it can generate plans.")
else:
    st.info("Fill in your growing conditions and click **Create my garden plan** to begin.")
    st.markdown("### A tiny challenge for today")
    st.write("Step outside for 10 minutes. Notice one plant, check the soil near it, and observe how much sunlight it receives.")
