# GreenBuddy 🌱

GreenBuddy is a beginner-friendly gardening companion built with Python, Streamlit, Ollama, and the open-weight Qwen2.5 1.5B model. It turns a few details about a user's growing space into a simple gardening plan and encourages a short outdoor task each day.

## Why it fits Touch Grass

The app is designed to make the screen the shortest part of the experience: get a plan, go outside, observe a plant, and come back only to record what you noticed.

## Tech stack

- Python
- Streamlit for the web interface
- Ollama for local model inference
- `qwen2.5:1.5b-instruct-q5_0` as the model

The selected Ollama model variant is listed with an Apache 2.0 license. Check the model card and license terms before redistributing model files.

## Requirements

- Python 3.10+
- Ollama installed
- Enough RAM and disk space to run the selected model
- Internet for the initial installation and model download; the model can then run locally

## Run locally

1. Install Python and Ollama.
2. Open a terminal in this project folder.
3. Create a virtual environment:

   **Windows**
   ```powershell
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install the Python dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Download and start the model once:

   ```bash
   ollama run qwen2.5:1.5b-instruct-q5_0
   ```

   After it responds, type `/bye` to exit. Keep Ollama running in the background.

6. Start GreenBuddy:

   ```bash
   streamlit run app.py
   ```

7. Open the local URL shown in the terminal.

## Demo checklist

- Enter a region, such as Kankavli, Maharashtra.
- Select a growing space and sunlight level.
- Generate a 7-day plan.
- Show the "10-minute task" and explain how it encourages an outdoor activity.
- If possible, take a real plant-care action and include your own photo in the DEV post.

## Limitations

- The model may produce incorrect or overly general advice. Verify recommendations with reliable local gardening resources.
- The app does not fetch live weather, soil, or frost-date data.
- Local inference requires the model to be downloaded and your computer to have sufficient resources.
- This is a starter project. Test it on your machine before presenting it as a working demo.

## Future improvements

- Add a region-specific plant knowledge base from reliable open sources.
- Add a simple garden journal and checkboxes for completed outdoor tasks.
- Allow users to choose between supported local models.
- Add citations for local growing guidance.

## License

Choose a license for your own code before publishing (for example, MIT). The model has its own separate license; see the model page.
